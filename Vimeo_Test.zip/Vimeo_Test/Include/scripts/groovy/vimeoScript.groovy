import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject

import com.kms.katalon.core.annotation.Keyword
import com.kms.katalon.core.checkpoint.Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling
import com.kms.katalon.core.testcase.TestCase
import com.kms.katalon.core.testcase.TestCaseFactory
import com.kms.katalon.core.testdata.TestData
import com.kms.katalon.core.testdata.TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository
import com.kms.katalon.core.testobject.TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI

import internal.GlobalVariable

import org.openqa.selenium.WebElement
import org.openqa.selenium.WebDriver
import org.openqa.selenium.By

import com.kms.katalon.core.mobile.keyword.internal.MobileDriverFactory
import com.kms.katalon.core.webui.driver.DriverFactory

import com.kms.katalon.core.testobject.RequestObject
import com.kms.katalon.core.testobject.ResponseObject
import com.kms.katalon.core.testobject.ConditionType
import com.kms.katalon.core.testobject.TestObjectProperty

import com.kms.katalon.core.mobile.helper.MobileElementCommonHelper
import com.kms.katalon.core.util.KeywordUtil

import com.kms.katalon.core.webui.exception.WebElementNotFoundException

import cucumber.api.java.en.And
import cucumber.api.java.en.Given
import cucumber.api.java.en.Then
import cucumber.api.java.en.When

class vimeoScript {

	@Given("Vimeo web application is launched")
	def navigateToLoginPage() {
	WebUI.openBrowser("https://vimeo.com/")
	//Check whether vimeo is launched
	if(WebUI.getText(findTestObject('Object Repository/Test_object/Page_Vimeo  The worlds only all-in-one video solution/a_Upload_logo'))) {
		println ("\n I am inside navigateToLoginPage ")
	}else {
		println ("\n URL not found ")
	}
	// wait
	Thread.sleep(2000)
	
	//click operation
	WebUI.click(findTestObject('Object Repository/Test_object/Page_Vimeo  The worlds only all-in-one vide_2822c6/a_Log in'))

}



@When("User enters (.*) and (.*)")
def enterCredentials(String useremail, String password) {
	println ("\n I am inside enterCredentials ")
	println ("Username : "+useremail)
	println ("password : "+password)

	//click operation
	//WebUI.click(findTestObject('Object Repository/Test_object/Page_Vimeo  The worlds only all-in-one vide_2822c6/a_Log in'))

	//enter email
	WebUI.setText(findTestObject('Object Repository/Test_object/Page_Vimeo  The worlds only all-in-one video solution/input_Log in to Vimeo_email'), useremail)

	//enter pwd
	WebUI.setText(findTestObject('Object Repository/Test_object/Page_Vimeo  The worlds only all-in-one video solution/input_Log in to Vimeo_password'), password)

	//click on login
	WebUI.click(findTestObject('Object Repository/Test_object/Page_Vimeo  The worlds only all-in-one video solution/input_A security code has been sent to your email address_iris_btn iris_btn--lg iris_btn--positive js-email-submit'))

	if(useremail == 'testapi378@gmail.com' && password == 'Testerapi@123') {
		println ("\n Authentication Successful")
	}else {
		println ("\n Authentication failed")
	}
}

@And("User selects a video and plays")
def playVideo() {

	//click on cross
	WebUI.click(findTestObject('Object Repository/Test1_OR/Page_Videos on Vimeo/path'))

	WebUI.maximizeWindow()

	//click on watch
	WebUI.click(findTestObject('Object Repository/Test1_OR/Page_Videos on Vimeo/a_Watch'))

	if(WebUI.getText(findTestObject('Object Repository/Page_Videos on Vimeo/a_Browse Videos'))) {
		println ("\n watch button working fine")
	}
	//click on browser
	WebUI.click(findTestObject('Object Repository/Test1_OR/Page_Videos on Vimeo/a_Browse Videos'))
	if(WebUI.getText(findTestObject('Object Repository/Page_Watch free videos  Upload HD and 4k videos with no ads/span_Watch human-curated Staff Picks'))) {
		println ("\n Inside Browse video")
	}

	//Video Playback Operation
	WebUI.doubleClick(findTestObject('Object Repository/Test1_OR/Page_Watch free videos  Upload HD and 4k videos with no ads/span_WWF - We Cant Negotiate with Ice'))

	if(WebUI.getAttribute(findTestObject('Object Repository/Test1_OR/Page_WWF - We Cant Negotiate with Ice on Vimeo/div_Open in app_vp-nudge-shade vp-nudge-shade-left vp-nudge-shade-invisible'), 5)) {
		println ("\n video playback starts")
	} else {
		println ("\n playback fails")
	}
}

@And("user checks the comment on the video")
def checkComment() {
	println ("\n video is comment is checked")

	//check for comment
}

@And("Navigate to any other video")
def navigateOtherVideo() {
	println ("\n navigated to other video")

	//naviagte to other video
	WebUI.navigateToUrl("https://vimeo.com/639466596")

	/*if(WebUI.getAttribute(findTestObject('Object Repository/Test1_OR/Page_GREEN JUICE - AAP FERG ft PHARRELL WILLIAMS on Vimeo/div_Open in app_vp-nudge-shade vp-nudge-shade-left vp-nudge-shade-invisible'), 5)) {
	 println ("\n Navigation succesful")
	 }*/

}

@Then("The comment is added and verified")
def verifyComment() {
	println ("\n comment is verified")

}
@And("save number of likes as test case variable")
def likeToTestVariable() {
	println ("\n Likes are saved as test variable")
}

@And("save number of views as Global variable")
def viewsToTestVariable() {
	println ("\n views are saved as Global variable")
	WebUI.closeBrowser()
}
}