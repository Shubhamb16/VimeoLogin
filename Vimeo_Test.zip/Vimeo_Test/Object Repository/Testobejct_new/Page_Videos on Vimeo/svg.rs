<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>svg</name>
   <tag></tag>
   <elementGuidId>34981173-707d-487a-abf8-f54b5f9d2140</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>svg[title=&quot;Close&quot;]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Try it'])[1]/following::*[name()='svg'][1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>svg</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>viewBox</name>
      <type>Main</type>
      <value>0 0 20 20</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>Close</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;wrap&quot;)/div[@class=&quot;wrap_content variant-v2&quot;]/main[@class=&quot;video-manager-app&quot;]/div[1]/div[1]/div[@class=&quot;video_manager&quot;]/div[1]/div[@class=&quot;video_manager__columns&quot;]/div[@class=&quot;video_manager__column video_manager__column--right&quot;]/div[@class=&quot;video_manager__primary_content_container&quot;]/div[@class=&quot;sc-kIPQKe cXsLLj&quot;]/div[@class=&quot;sc-ibxdXY kRYbYH&quot;]/div[@class=&quot;sc-ghUbLI eRaeVf sc-RefOD ixjwwh&quot;]/div[@class=&quot;sc-bwCtUz gGZREj&quot;]/button[@class=&quot;sc-gxMtzJ fztsFm&quot;]/span[@class=&quot;sc-gzOgki gyENOz&quot;]/svg[1]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Try it'])[1]/following::*[name()='svg'][1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Read more'])[1]/following::*[name()='svg'][1]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Uploading 0 of 0 videos'])[1]/preceding::*[name()='svg'][2]</value>
   </webElementXpaths>
</WebElementEntity>
