import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.webui.keyword.internal.WebUIAbstractKeyword
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

String name = 'Automation'

//open browser
WebUI.openBrowser('https://vimeo.com/')

//click on login button
WebUI.click(findTestObject('Object Repository/Test_object/Page_Vimeo  The worlds only all-in-one video solution/a_Log in'))

//enter email
WebUI.setText(findTestObject('Object Repository/Test_object/Page_Vimeo  The worlds only all-in-one video solution/input_Log in to Vimeo_email'),'testapi378@gmail.com')

//enter pwd
WebUI.setText(findTestObject('Object Repository/Test_object/Page_Vimeo  The worlds only all-in-one video solution/input_Log in to Vimeo_password'),'Testerapi@123')

//click on login
WebUI.click(findTestObject('Object Repository/Test_object/Page_Vimeo  The worlds only all-in-one video solution/input_A security code has been sent to your email address_iris_btn iris_btn--lg iris_btn--positive js-email-submit'))

//closing popup
WebUI.click(findTestObject('Object Repository/Test_object/Page_Videos on Vimeo/button_Try it_sc-gxMtzJ fztsFm'))

//maximize window
WebUI.maximizeWindow()

//click on watch button
WebUI.click(findTestObject('Object Repository/Test_object/Page_Videos on Vimeo/a_Watch'))

//click on browser videos
WebUI.click(findTestObject('Object Repository/Test_object/Page_Videos on Vimeo/a_Browse Videos'))

//Play of video
WebUI.doubleClick(findTestObject('Object Repository/Test_object/Page_Watch free videos  Upload HD and 4k videos with no ads/div_0045'))

//Wait period
Thread.sleep(2000)

//Navigate to homepage
WebUI.click(findTestObject('Object Repository/Test_object/Page_Videos on Vimeo/a_Watch'))

//Navigate to another video
WebUI.navigateToUrl("https://vimeo.com/639466596")

//Printing attribute value
attributes = WebUI.getAttribute(findTestObject('Object Repository/Test1_OR/Page_GREEN JUICE - AAP FERG ft PHARRELL WILLIAMS on Vimeo/div_Open in app_vp-nudge-shade vp-nudge-shade-left vp-nudge-shade-invisible'), attributes)
println (attributes)

//Retriving Likes value 
Likes = WebUI.getAttribute(findTestObject('Page_WWF - We Cant Negotiate with Ice on Vimeo/span_531'), Likes)

//Retriving Views values
Views = WebUI.getAttribute(findTestObject('Object Repository/Test1_OR/Page_WWF - We Cant Negotiate with Ice on Vimeo/span_13.1K'), '')

//close browser
WebUI.closeBrowser()
