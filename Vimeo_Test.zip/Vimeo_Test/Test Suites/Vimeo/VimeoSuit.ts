<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>VimeoSuit</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>3</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>true</rerunImmediately>
   <testSuiteGuid>dc7b1a37-1561-407f-9d35-4c9a4fa161d0</testSuiteGuid>
   <testCaseLink>
      <guid>191a308f-ad0d-416c-8114-d97b2360ef2d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/vimeo</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>8bc2b42a-84b4-4ba2-8713-2ee4872ba91d</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/RunFeatureFIle</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
